# whatsapp_clone

A whatsapp UI clone

Properly documented to help you get started with Flutter.

Please leave a star. Thats how I know people appreciate. Thanks :heart:
## Getting Started

For help getting started with Flutter, view our online
[documentation](https://flutter.io/).
